# NOVA + Arden OS

Buka index.html, atau jalankan static server dari folder ini. Unggah seluruh folder untuk menjaga aset dan subhalaman.

- index.html: website utama NOVA.
- arden-os/index.html: subhalaman Arden OS.
- arden-os/blueprint.html: blueprint lengkap dan interaktif.
- assets/integrations.js: integrasi Supabase dan simulasi dari website asal, dipertahankan.

Koneksi Supabase tetap bergantung account, jaringan dan izin tabel yang sudah ada. WhatsApp mempertahankan nomor pada sumber asli. Website tidak memasang atau mengaktifkan agent Hermes.
